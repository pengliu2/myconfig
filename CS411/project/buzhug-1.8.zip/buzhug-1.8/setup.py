#!/usr/bin/env python

from distutils.core import setup

setup(name='buzhug',
      version='1.8',
      description='Buzhug, a pure-Python database',
      author='Pierre Quentel',
      author_email='quentel.pierre@wanadoo.fr',
      url='http://buzhug.sourceforge.net/',
      packages = ['buzhug']
     )

